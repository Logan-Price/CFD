Std-1 - Standard blending function, dt=1e-7s, ACo = 0.011
Std-2 - Same as Std-1, but dt=1e-6s, ACo = 0.11
Std-3 - Same as Std-1, but dt=1e-5s, ACo = 1.11
Std-4 - Same as Std-1, but dt=2.5e-s, ACo = 2.79


